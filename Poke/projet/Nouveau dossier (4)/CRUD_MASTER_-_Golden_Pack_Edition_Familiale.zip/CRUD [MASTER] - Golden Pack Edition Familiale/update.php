<?php 

    // A vous de le déchiffrer :) //

    require("./conn.php");

    if($connexion){
        
        if($_GET && $_GET["id"]){
            $userId = $_GET["id"];
            
            $execResult = $connexion->query("SELECT * FROM users WHERE id=$userId");
            $result = $execResult->fetchAll(PDO::FETCH_ASSOC);
        }

        else{
            $userID = $_POST["userID"];
            $newUserName = $_POST["username"];
            $newPassword = $_POST["pwd"];

            $execResult = $connexion->query("UPDATE users SET nom = '$newUserName', motDePasse = '$newPassword' WHERE id='$userID'");
            var_dump($execResult);
        }
    }
?>

<form method="POST" action="./update.php">

    <input type="hidden" name="userID" value="<?php if(isset($result)){ echo $_GET["id"];} ?>">

    <div>
        <label for="uname">Votre nom : </label>
        <input type="text" name="username" id="uname" value="<?php if(isset($result)){ echo $result[0]["nom"];} ?>">
    </div>

    <div>
        <label for="mdp">Votre mot de passe : </label>
        <input type="password" name="pwd" id="mdp" value="<?php if(isset($result)){ echo $result[0]["motDePasse"];} ?>">
    </div>

    <input type="submit" value="Mettre à jour">
</form>