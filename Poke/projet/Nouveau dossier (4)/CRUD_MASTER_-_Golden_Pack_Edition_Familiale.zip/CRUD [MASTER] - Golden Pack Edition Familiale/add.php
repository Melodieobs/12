<?php 

    // Script d'ajout de tuple(s) //

    // Requiert le fichier de connexion à la base de données
    require("./conn.php");

    // S'assure que la connexion à la base de données soit faite
    if($connexion){ 

        // Récupère les données issues du formulaire d'ajout (cf. formulaireAjout.html)
        $username = $_POST['username'];
        $password = $_POST['pwd'];

        // Déclaration puis exécution de la requête d'ajout
        // (dynamique en fonction des données issues du formulaire)
        $execResult = $connexion->query("INSERT INTO users (nom, motDePasse) VALUES ('$username', '$password')");

        /* var_dump($execResult); */

    }
?>